"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  Check,
  ChevronDown,
  LoaderCircle,
  LogOut,
  Pencil,
  Plus,
  Save,
  Trash2,
  X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { z } from "zod";
import { Project } from "@/lib/types";

const dashboardProjectSchema = z.object({
  kind: z.enum(["industry", "printing"]),
  title: z.string().min(3, "Title must contain at least 3 characters"),
  summary: z
    .string()
    .min(10, "Summary must contain at least 10 characters")
    .max(240),
  description: z
    .string()
    .min(20, "Description must contain at least 20 characters")
    .max(5000),
  image: z.string().url("Enter a complete image URL"),
  tags: z.string().min(1, "Add at least one tag"),
  featured: z.boolean(),
});
type ProjectFormValues = z.infer<typeof dashboardProjectSchema>;

const blankProject: ProjectFormValues = {
  kind: "industry",
  title: "",
  summary: "",
  description: "",
  image: "",
  tags: "",
  featured: false,
};

function asFormValues(project: Project): ProjectFormValues {
  return {
    kind: project.kind,
    title: project.title,
    summary: project.summary,
    description: project.description,
    image: project.image,
    tags: project.tags.join(", "),
    featured: project.featured,
  };
}

export function AdminDashboard({
  initialProjects,
  email,
}: {
  initialProjects: Project[];
  email: string;
}) {
  const router = useRouter();
  const [projects, setProjects] = useState(initialProjects);
  const [editing, setEditing] = useState<Project | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [removing, setRemoving] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<ProjectFormValues>({
    resolver: zodResolver(dashboardProjectSchema),
    defaultValues: blankProject,
  });

  const openNew = () => {
    setEditing(null);
    reset(blankProject);
    setIsFormOpen(true);
  };
  const openEdit = (project: Project) => {
    setEditing(project);
    reset(asFormValues(project));
    setIsFormOpen(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const closeForm = () => {
    setIsFormOpen(false);
    setEditing(null);
    reset(blankProject);
  };
  const save = async (values: ProjectFormValues) => {
    const payload = {
      ...values,
      tags: values.tags
        .split(",")
        .map((tag) => tag.trim())
        .filter(Boolean),
    };
    const response = await fetch(
      editing ? `/api/projects/${editing.id}` : "/api/projects",
      {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      },
    );
    const data = await response.json();
    if (!response.ok) {
      toast.error(data.message || "The project could not be saved.");
      return;
    }
    if (editing)
      setProjects((current) =>
        current.map((project) => (project.id === editing.id ? data : project)),
      );
    else setProjects((current) => [data, ...current]);
    toast.success(editing ? "Project updated." : "Project added.");
    closeForm();
    router.refresh();
  };
  const remove = async (project: Project) => {
    if (!window.confirm(`Remove “${project.title}”? This cannot be undone.`))
      return;
    setRemoving(project.id);
    const response = await fetch(`/api/projects/${project.id}`, {
      method: "DELETE",
    });
    const data = await response.json();
    setRemoving(null);
    if (!response.ok) {
      toast.error(data.message || "The project could not be removed.");
      return;
    }
    setProjects((current) => current.filter((item) => item.id !== project.id));
    toast.success("Project removed.");
    router.refresh();
  };
  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.replace("/");
    router.refresh();
  };
  return (
    <div className="container py-10 md:py-14">
      <div className="flex flex-col gap-5 border-b border-[#d5dad2] pb-7 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="eyebrow">Administration</p>
          <h1 className="mt-4 text-4xl font-extrabold tracking-[-.065em] md:text-5xl">
            Project dashboard
          </h1>
          <p className="mt-3 text-sm text-[#61706b]">Signed in as {email}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="button button-ghost" onClick={logout}>
            <LogOut size={16} /> Sign out
          </button>
          <button className="button button-primary" onClick={openNew}>
            <Plus size={17} /> New project
          </button>
        </div>
      </div>
      {isFormOpen && (
        <section className="mt-8 rounded-2xl border border-[#bfc9bc] bg-white p-5 shadow-sm md:p-8">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="eyebrow">
                {editing ? "Update project" : "New project"}
              </p>
              <h2 className="mt-3 text-2xl font-extrabold tracking-[-.05em]">
                {editing ? editing.title : "Add a project"}
              </h2>
            </div>
            <button
              onClick={closeForm}
              className="grid h-9 w-9 place-items-center rounded-full border border-[#d5dad2]"
              aria-label="Close form"
            >
              <X size={17} />
            </button>
          </div>
          <form
            onSubmit={handleSubmit(save)}
            className="mt-7 grid gap-5"
            noValidate
          >
            <div className="grid gap-5 md:grid-cols-2">
              <Field label="Project type" error={errors.kind?.message}>
                <select className="input" {...register("kind")}>
                  <option value="industry">Industrial project</option>
                  <option value="printing">3D printing project</option>
                </select>
              </Field>
              <Field label="Title" error={errors.title?.message}>
                <input
                  className="input"
                  placeholder="Project title"
                  {...register("title")}
                />
              </Field>
            </div>
            <Field label="Short summary" error={errors.summary?.message}>
              <input
                className="input"
                placeholder="A clear one-sentence introduction"
                {...register("summary")}
              />
            </Field>
            <Field label="Description" error={errors.description?.message}>
              <textarea
                className="input resize-y"
                rows={5}
                placeholder="What was the challenge and how did the work solve it?"
                {...register("description")}
              />
            </Field>
            <div className="grid gap-5 md:grid-cols-[1.3fr_.7fr]">
              <Field label="Image URL" error={errors.image?.message}>
                <input
                  className="input"
                  type="url"
                  placeholder="https://images.example/project.jpg"
                  {...register("image")}
                />
              </Field>
              <Field
                label="Tags (comma-separated)"
                error={errors.tags?.message}
              >
                <input
                  className="input"
                  placeholder="Automation, Steelwork"
                  {...register("tags")}
                />
              </Field>
            </div>
            <label className="flex w-fit items-center gap-3 rounded-lg bg-[#edf0ea] px-3 py-2 text-sm font-bold">
              <input
                type="checkbox"
                className="h-4 w-4 accent-[#10201e]"
                {...register("featured")}
              />{" "}
              Show in homepage slider
            </label>
            <div className="flex flex-wrap gap-3">
              <button
                disabled={isSubmitting}
                className="button button-dark disabled:opacity-60"
              >
                {isSubmitting ? (
                  <LoaderCircle className="animate-spin" size={16} />
                ) : (
                  <Save size={16} />
                )}
                {isSubmitting
                  ? "Saving"
                  : editing
                    ? "Save changes"
                    : "Create project"}
              </button>
              <button
                type="button"
                className="button button-ghost"
                onClick={closeForm}
              >
                Cancel
              </button>
            </div>
          </form>
        </section>
      )}
      <section className="mt-9">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-extrabold tracking-[-.04em]">
            All projects
          </h2>
          <span className="rounded-full bg-[#dfe5dc] px-3 py-1 text-xs font-bold">
            {projects.length} total
          </span>
        </div>
        <div className="overflow-x-auto rounded-2xl border border-[#d5dad2] bg-white">
          <table className="w-full min-w-[700px] text-left text-sm">
            <thead className="border-b border-[#d5dad2] bg-[#edf0ea] text-xs uppercase tracking-[.11em] text-[#53625b]">
              <tr>
                <th className="p-4">Project</th>
                <th className="p-4">Type</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((project) => (
                <tr
                  key={project.id}
                  className="border-b border-[#e6e9e3] last:border-0"
                >
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={project.image}
                        alt=""
                        className="h-10 w-12 rounded-md object-cover"
                      />
                      <div>
                        <p className="font-bold">{project.title}</p>
                        <p className="mt-1 max-w-[270px] truncate text-xs text-[#61706b]">
                          {project.tags.join(" · ")}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 capitalize text-[#61706b]">
                    {project.kind === "printing" ? "3D Printing" : "Industrial"}
                  </td>
                  <td className="p-4">
                    {project.featured ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-[#e6f4cb] px-2 py-1 text-xs font-bold text-[#47691d]">
                        <Check size={12} /> Featured
                      </span>
                    ) : (
                      <span className="text-xs text-[#61706b]">Catalogue</span>
                    )}
                  </td>
                  <td className="p-4">
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => openEdit(project)}
                        className="button button-ghost !px-3 !py-2"
                      >
                        <Pencil size={15} /> Edit
                      </button>
                      <button
                        disabled={removing === project.id}
                        onClick={() => remove(project)}
                        className="button border border-[#edc5b7] !px-3 !py-2 text-[#ab472d] hover:bg-[#fff2ed] disabled:opacity-50"
                      >
                        {removing === project.id ? (
                          <LoaderCircle className="animate-spin" size={15} />
                        ) : (
                          <Trash2 size={15} />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!projects.length && (
            <div className="p-12 text-center text-sm text-[#61706b]">
              No projects yet. Add your first one above.
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
      {error && <p className="error">{error}</p>}
    </div>
  );
}

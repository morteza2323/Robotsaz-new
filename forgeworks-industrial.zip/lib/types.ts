export type ProjectKind = "industry" | "printing";

export type Project = {
  id: string;
  slug: string;
  kind: ProjectKind;
  title: string;
  summary: string;
  description: string;
  image: string;
  tags: string[];
  featured: boolean;
  createdAt: string;
};

export const projectKindLabels: Record<ProjectKind, string> = {
  industry: "Industrial Projects",
  printing: "3D Printing Projects",
};

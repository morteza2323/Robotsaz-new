import { NextRequest, NextResponse } from "next/server";
import { getAdminSession } from "@/lib/auth";
import { deleteProject, updateProject } from "@/lib/projects";
import { projectSchema } from "@/lib/validation";

type Context = { params: Promise<{ id: string }> };

export async function PUT(request: NextRequest, { params }: Context) {
  if (!(await getAdminSession())) return NextResponse.json({ message: "Unauthorised" }, { status: 401 });
  const parsed = projectSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ message: "Project data is invalid." }, { status: 400 });
  const updated = await updateProject((await params).id, parsed.data);
  if (!updated) return NextResponse.json({ message: "Project not found" }, { status: 404 });
  return NextResponse.json(updated);
}

export async function DELETE(_request: NextRequest, { params }: Context) {
  if (!(await getAdminSession())) return NextResponse.json({ message: "Unauthorised" }, { status: 401 });
  const removed = await deleteProject((await params).id);
  if (!removed) return NextResponse.json({ message: "Project not found" }, { status: 404 });
  return NextResponse.json({ ok: true });
}

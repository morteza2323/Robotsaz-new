# ForgeWorks Industrial Website

A responsive Next.js + TypeScript website for an industrial fabrication and 3D-printing company.

## Run locally

```powershell
Copy-Item .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000`.

The sample `.env.example` contains the local administrator sign-in values. Replace `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and `JWT_SECRET` with strong production values before deploying.

## Included

- Responsive industrial-themed home, about, contact, project directory, project detail, login, dashboard, and 404 pages.
- Separate searchable industrial and 3D-printing project catalogues.
- Animated cards and reveals with Framer Motion.
- JWT, HttpOnly-cookie admin login with basic login/contact rate limiting.
- Secure admin CRUD API for project management.
- React Hook Form and Zod validation on client and API routes.
- Toast feedback for sign-in, project changes, and contact enquiries.

## Data and deployment notes

Projects are initially seeded in `data/projects.json`; the protected API updates that file so the app works immediately in a local Node deployment. For a serverless or multi-instance production deployment, replace the small repository in `lib/projects.ts` with a database (for example PostgreSQL + Prisma).

`/api/contact` validates and rate-limits submissions and returns a success response. Connect a transactional email provider such as Resend or Postmark in that route before using it for live customer enquiries.
